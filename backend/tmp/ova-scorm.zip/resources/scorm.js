(function (global) {
  let api = null

  function findApi(win) {
    let current = win
    let attempts = 0
    while (current && attempts < 500) {
      if (current.API) {
        return current.API
      }
      attempts += 1
      current = current.parent
    }
    return null
  }

  function getApi() {
    if (api) {
      return api
    }

    api = findApi(global)

    if (!api && global.opener) {
      api = findApi(global.opener)
    }

    return api
  }

  function initialize() {
    const handle = getApi()
    if (!handle) {
      return false
    }
    return handle.LMSInitialize('') === 'true'
  }

  function getValue(element) {
    const handle = getApi()
    if (!handle) {
      return ''
    }
    return handle.LMSGetValue(element)
  }

  function setValue(element, value) {
    const handle = getApi()
    if (!handle) {
      return false
    }
    return handle.LMSSetValue(element, value) === 'true'
  }

  function commit() {
    const handle = getApi()
    if (!handle) {
      return false
    }
    return handle.LMSCommit('') === 'true'
  }

  function finish() {
    const handle = getApi()
    if (!handle) {
      return false
    }
    return handle.LMSFinish('') === 'true'
  }

  global.GenovaScorm = {
    initialize,
    getValue,
    setValue,
    commit,
    finish,
  }
})(window)
