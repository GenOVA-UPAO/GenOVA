window.addEventListener('DOMContentLoaded', function () {
  const statusNode = document.getElementById('scorm-status')
  const completeButton = document.getElementById('complete-btn')

  const initialized = window.GenovaScorm && window.GenovaScorm.initialize()

  if (!initialized) {
    statusNode.textContent =
      'No se detectó API LMS (modo vista previa). El contenido sigue siendo navegable.'
    return
  }

  const currentStatus = window.GenovaScorm.getValue('cmi.core.lesson_status')

  if (!currentStatus || currentStatus === 'not attempted') {
    window.GenovaScorm.setValue('cmi.core.lesson_status', 'incomplete')
    window.GenovaScorm.commit()
    statusNode.textContent = 'Estado LMS: incomplete'
  } else {
    statusNode.textContent = 'Estado LMS actual: ' + currentStatus
  }

  completeButton.addEventListener('click', function () {
    window.GenovaScorm.setValue('cmi.core.lesson_status', 'completed')
    window.GenovaScorm.setValue('cmi.core.score.raw', '100')
    window.GenovaScorm.commit()
    statusNode.textContent = 'Estado LMS: completed (guardado)'
  })

  window.addEventListener('beforeunload', function () {
    window.GenovaScorm.commit()
    window.GenovaScorm.finish()
  })
})
